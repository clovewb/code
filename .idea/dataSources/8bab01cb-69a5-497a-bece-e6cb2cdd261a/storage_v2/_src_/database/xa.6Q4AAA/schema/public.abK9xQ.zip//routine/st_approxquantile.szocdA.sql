create function st_approxquantile(rast raster, sample_percent double precision, quantile double precision) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ( public._ST_quantile($1, 1, TRUE, $2, ARRAY[$3]::double precision[])).value
$$;

alter function st_approxquantile(raster, double precision, double precision) owner to postgres;

