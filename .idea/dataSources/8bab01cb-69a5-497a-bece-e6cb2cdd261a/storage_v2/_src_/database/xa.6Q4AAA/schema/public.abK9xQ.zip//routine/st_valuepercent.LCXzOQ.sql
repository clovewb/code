create function st_valuepercent(rast raster, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$
SELECT value, percent FROM public._ST_valuecount($1, 1, TRUE, $2, $3)
$$;

alter function st_valuepercent(raster, double precision[], double precision, out double precision, out double precision) owner to postgres;

